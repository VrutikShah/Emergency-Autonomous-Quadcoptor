#include "stm32f10x.h"
#include "SPI_NRF.h"
#include "usart1.h"	 
#include "led.h"

 u8 status;		 
 u8 txbuf[4];	 
 u8 rxbuf[4];	 
 u8 i; 
int main(void)
{      
	USART1_Config(); //115200
   LED_GPIO_Config(); 
   SPI_NRF_Init(); 

	printf("\r\n NRF24L01 \r\n");
	 
   	status = NRF_Check();   		
	  if(status == SUCCESS)	   
	   		printf("\r\n      OK\r\n");  
	  else	  
	   	  printf("\r\n   Error \r\n");
			  
while(1)
	{  		 	
 	printf("\r\n From the machine goes into receive mode\r\n"); 
	NRF_RX_Mode();
	 
	status = NRF_Rx_Dat(rxbuf);

	if(status == RX_DR)
	{
		printf("\r\n Slave receives data sent by the master:"); 
	 for(i=0;i<4;i++)
	 {	
	 	 printf("%d,",rxbuf[i]); 
	 	 rxbuf[i]+=1;	  
		 txbuf[i] = rxbuf[i];					
		}
		 printf("\r\n");
			GPIO_WriteBit(GPIOB, GPIO_Pin_9, 
		               (BitAction)((1-GPIO_ReadOutputDataBit(GPIOB, GPIO_Pin_9)))); 

	}  
#if 1	
		printf("\r\n From machine to enter from the reply transmission mode\r\n"); 
	  NRF_TX_Mode();

	 do
	   { 	  
		status = NRF_Tx_Dat(txbuf);
		}while(status == MAX_RT);
	} 
#endif 
	
} 
