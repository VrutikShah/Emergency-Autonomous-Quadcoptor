/* NRF24L01
**********************************************************************************/
#include "stm32f10x.h"
#include "SPI_NRF.h"
#include "usart1.h"
#include "led.h"

u8 status;	
u8 txbuf[4]={0,1,2,3};	 
u8 rxbuf[4];			
int i=0;

int main(void)
{
  
  SPI_NRF_Init();
  LED_GPIO_Config(); 
	USART1_Config();

	printf("\r\n  NRF24L01  \r\n");

   status = NRF_Check(); 

   if(status == SUCCESS)	   
   		 printf("\r\n      NRF MCU OK\r\n");  
   else	  
   	   printf("\r\n  NRF MCU NOT OK \r\n");
	 
	 
	NRF_TX_Mode();

	while(1)
	{	
		 	
		status = NRF_Tx_Dat(txbuf);	  
		  
		  switch(status)
		  {
	  	  case MAX_RT:
			 	 	printf("\r\n The host does not receive an acknowledgment signal sending times exceed the limit value, the transmission failed. \r\n");
				 break;
	
			  case ERROR:
			  	 	printf("\r\n Unknown cause of transmission failure. \r\n");
				 break;
	
			  case TX_DS:
			  		printf("\r\n Host receives the signal from the transponder, has been sent successfully! \r\n");	 	
						GPIO_WriteBit(GPIOB, GPIO_Pin_9, 
		               (BitAction)((1-GPIO_ReadOutputDataBit(GPIOB, GPIO_Pin_9)))); 

				 break;  								
		  }		
			
	#if 1
	 	printf("\r\n Host goes into receive mode. \r\n");	
		NRF_RX_Mode();
	
		status = NRF_Rx_Dat(rxbuf);
	
			switch(status)
			{
			 case RX_DR:
				 printf("\r\n Host receives the data sent from the machine��");
			 	 for(i=0;i<4;i++)
				 {					
					printf("%d,",rxbuf[i]);
					txbuf[i] =rxbuf[i];
				 }
				 printf("\r\n");
				 /* LED1 */      
			   GPIO_WriteBit(GPIOB, GPIO_Pin_8, 
		               (BitAction)((1-GPIO_ReadOutputDataBit(GPIOB, GPIO_Pin_8)))); 

			   break;
	
			 case ERROR:
				  	printf("\r\n Host receives an error.   \r\n");
				  break;  		
			}
		#endif//
		} 

}


