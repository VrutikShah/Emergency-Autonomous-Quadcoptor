#include "stm32f10x.h"
#include "led.h"


void Delay(__IO u32 nCount);


int main(void)
{	
	/* LED */
	LED_GPIO_Config();

	while (1)
	{
		LED1( ON );			  
		Delay(0x0FFFEF);
		LED1( OFF );		  
		
		LED2( ON );
		Delay(0x0FFFEF);
		LED2( OFF );  		
	
	}
}

void Delay(__IO u32 nCount)	 
{
	for(; nCount != 0; nCount--);
} 

