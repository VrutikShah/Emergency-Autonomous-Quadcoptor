#include "stm32f10x.h"
#include "usart1.h"
#include "rtc.h"


struct rtc_time systmtime;


/**
  * @brief  Main program.
  * @param  None
  * @retval : None
  */
int main()
{
			
	  NVIC_Configuration();
	  USART1_Config();
	  RTC_CheckAndConfig(&systmtime);

	
	  /* Display time in infinite loop */
	  Time_Show(&systmtime);
}




