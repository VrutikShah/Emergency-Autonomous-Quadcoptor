#include "stm32f10x.h"
#include "usart1.h"


int main(void)
{	
	/* USART1 config 115200 8-N-1 */
	USART1_Config();
	
	printf("\r\n this is a printf demo \r\n");

	printf("\r\nSTM32-M3:) \r\n");
		
	USART1_printf(USART1, "\r\n This is a USART1_printf demo \r\n");
	
	USART1_printf(USART1, "\r\n ("__DATE__ " - " __TIME__ ") \r\n");

	for(;;)
	{
		
	}
}
